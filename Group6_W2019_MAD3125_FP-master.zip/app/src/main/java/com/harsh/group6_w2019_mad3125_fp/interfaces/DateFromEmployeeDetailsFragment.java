package com.harsh.group6_w2019_mad3125_fp.interfaces;

import model.abstracts.Employee;

public interface DateFromEmployeeDetailsFragment  {
    public void employeeObject(Employee employee);
}
