package com.harsh.group6_w2019_mad3125_fp.interfaces;

import android.widget.RadioGroup;
import android.widget.TextView;

public interface DataFromPartTimeFragment  {

    public void viewsFromPartTimeFragment(TextView name, TextView age , RadioGroup gender, TextView ratePerHour, TextView numberOfHours , TextView dateOfBirth , RadioGroup vehicle);
}
