package com.harsh.group6_w2019_mad3125_fp.interfaces;

import android.widget.RadioGroup;
import android.widget.TextView;

import model.abstracts.Vehicle;

public interface DataFromAddEmployeeFragment
{

    public void viewsFromAddEmployeeFragment(TextView name, TextView age, RadioGroup gender , TextView date , RadioGroup vehicle);




}
