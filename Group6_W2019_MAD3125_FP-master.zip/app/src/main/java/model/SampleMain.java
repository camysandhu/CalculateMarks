package model;

public class SampleMain {

	//public static ArrayList<Employee> mainMethod() {
		//System.out.println("Hello world");
		
		//Employee e1 = new Employee("Mahesh", 20);
		
		//System.out.println(e1.calcBirthYear());
		
		

			
		
		

		//SingleToneExample  singleton = SingleToneExample.getObj();

				
		//singleton.displayList();
		
		
		//return singleton.getList();
				
	//}

}
