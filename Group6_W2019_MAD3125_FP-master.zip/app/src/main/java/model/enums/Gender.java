package model.enums;

public enum Gender {
		MALE, FEMALE
}
