package model;

public class UserDefinedExe extends Exception {
	public UserDefinedExe(String message) {
		super(message);
		
		// TODO Auto-generated constructor stub
	}
	

}
