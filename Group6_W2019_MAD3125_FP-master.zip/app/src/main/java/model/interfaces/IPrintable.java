package model.interfaces;


@FunctionalInterface
public interface IPrintable {
			String printData();
			
			
}
